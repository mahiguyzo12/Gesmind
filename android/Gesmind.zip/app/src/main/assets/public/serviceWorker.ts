const CACHE_NAME = 'gesmind-hybrid-v1';
const urlsToCache = [
  '/',
  '/index.html',
  '/manifest.json',
  '/index.css',
  // Cache local built assets
  '/assets/vendor-DFHLW2GP.js',
  '/assets/index-59HrrqB8.js',
  '/assets/index-BYqte_BQ.js',
  '/assets/logo-zdQMajaK.svg'
];

self.addEventListener('install', (event) => {
  self.skipWaiting();
  event.waitUntil(
    caches.open(CACHE_NAME).then(async (cache) => {
      try {
        await cache.addAll(urlsToCache);
      } catch (e) {
        // best-effort: try each individually
        for (const url of urlsToCache) {
          try {
            await cache.add(url);
          } catch (err) {
            // ignore
          }
        }
      }

      // Try to prefetch critical external resources (best-effort)
      const external = [
        'https://cdn.tailwindcss.com',
        'https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap'
      ];
      for (const u of external) {
        try {
          const resp = await fetch(u, { mode: 'cors' });
          if (resp && resp.ok) {
            await cache.put(u, resp.clone());
          }
        } catch (e) {
          // ignore failures
        }
      }

      return;
    })
  );
});

self.addEventListener('fetch', (event) => {
  event.respondWith(
    caches.match(event.request).then((response) => {
      if (response) return response;
      return fetch(event.request).catch(() => {
        // Navigation fallback to index.html for SPA
        if (event.request.mode === 'navigate' || (event.request.method === 'GET' && event.request.headers.get('accept')?.includes('text/html'))) {
          return caches.match('/index.html');
        }
        return new Response('', { status: 504, statusText: 'offline' });
      });
    })
  );
});

self.addEventListener('activate', (event) => {
  const cacheWhitelist = [CACHE_NAME];
  event.waitUntil(
    caches.keys().then((cacheNames) => Promise.all(
      cacheNames.map((cacheName) => {
        if (cacheWhitelist.indexOf(cacheName) === -1) return caches.delete(cacheName);
      })
    ))
  );
});
